import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-home',
  templateUrl: './account-home.component.html',
  styleUrls: ['./account-home.component.css']
})
export class AccountHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
