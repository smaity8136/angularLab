import { Component } from '@angular/core';

@Component({
  selector: "fancy-text",
  styleUrls: ["./fancy-text.component.css"],
  template: "<input type='text'/>"
})
export class FancyText { 
}